import torch
import torch.nn as nn
import torch.nn.functional as F
from dassl.engine import TRAINER_REGISTRY, TrainerX
from dassl.optim import build_optimizer, build_lr_scheduler
from dassl.metrics import compute_accuracy

from clip import clip
from clip.model import convert_weights

from .coop import load_clip_to_cpu
from .util import CUSTOM_TEMPLATES, ENSEMBLE_TEMPLATES, load_features, pp_solver

import os
import os.path as osp


@TRAINER_REGISTRY.register()
class ZeroshotCLIP(TrainerX):
    def build_model(self):
        cfg = self.cfg
        classnames = self.dm.dataset.classnames

        print(f"Loading CLIP (backbone: {cfg.MODEL.BACKBONE.NAME})")
        clip_model = load_clip_to_cpu(cfg)
        clip_model.to(self.device)
        if cfg.DATASET.SUBSAMPLE_CLASSES != 'all':
            temp = "a photo of a {}."
        else:
            temp = CUSTOM_TEMPLATES[cfg.DATASET.NAME]
        prompts = [temp.format(c.replace("_", " ")) for c in classnames]
        print(f"Prompts: {prompts}")
        prompts = torch.cat([clip.tokenize(p) for p in prompts])
        prompts = prompts.to(self.device)

        with torch.no_grad():
            text_features = clip_model.encode_text(prompts)
            text_features = text_features / text_features.norm(dim=-1,
                                                               keepdim=True)

        self.text_features = text_features
        self.clip_model = clip_model

    def model_inference(self, image):
        image_features = self.clip_model.encode_image(image)
        image_features = image_features / image_features.norm(dim=-1,
                                                              keepdim=True)
        logit_scale = self.clip_model.logit_scale.exp()
        logits = logit_scale * image_features @ self.text_features.t()
        return logits


@TRAINER_REGISTRY.register()
class ZeroshotCLIP2(ZeroshotCLIP):
    """Prompt ensembling."""
    def build_model(self):
        cfg = self.cfg
        classnames = self.dm.dataset.classnames


        print(f"Loading CLIP (backbone: {cfg.MODEL.BACKBONE.NAME})")
        clip_model = load_clip_to_cpu(cfg)
        clip_model.to(self.device)

        for params in clip_model.parameters():
            params.requires_grad_(False)

        templates = ENSEMBLE_TEMPLATES[cfg.DATASET.NAME]
        num_temp = len(templates)
        print(f"Prompt ensembling (n={num_temp})")

        mean_text_features = 0
        for i, temp in enumerate(templates):
            prompts = [temp.format(c.replace("_", " ")) for c in classnames]
            prompts = torch.cat([clip.tokenize(p)
                                 for p in prompts]).to(self.device)
            text_features = clip_model.encode_text(prompts)
            text_features = text_features / text_features.norm(dim=-1,
                                                               keepdim=True)
            mean_text_features = mean_text_features + text_features
        mean_text_features = mean_text_features / num_temp
        mean_text_features = mean_text_features / mean_text_features.norm(
            dim=-1, keepdim=True)

        self.text_features = mean_text_features
        self.clip_model = clip_model


class TextEncoder(nn.Module):
    def __init__(self, clip_model):
        super().__init__()
        self.transformer = clip_model.transformer
        self.positional_embedding = clip_model.positional_embedding
        self.ln_final = clip_model.ln_final
        self.text_projection = clip_model.text_projection
        self.dtype = clip_model.dtype

    def forward(self, prompts, tokenized_prompts):
        x = prompts + self.positional_embedding.type(self.dtype)
        x = x.permute(1, 0, 2)  # NLD -> LND
        x = self.transformer(x)
        x = x.permute(1, 0, 2)  # LND -> NLD
        x = self.ln_final(x).type(self.dtype)

        # x.shape = [batch_size, n_ctx, transformer.width]
        # take features from the eot embedding (eot_token is the highest number in each sequence)
        x = x[torch.arange(x.shape[0]),
              tokenized_prompts.argmax(dim=-1)] @ self.text_projection

        return x


@TRAINER_REGISTRY.register()
class CalibratedZeroshotCLIP(TrainerX):
    def build_model(self):
        cfg = self.cfg
        classnames = self.dm.dataset.classnames

        print(f"Loading CLIP (backbone: {cfg.MODEL.BACKBONE.NAME})")
        clip_model = load_clip_to_cpu(cfg)
        clip_model.to(self.device)

        use_ensemble = cfg.TRAINER.ZS.ENSEMBLE

        if use_ensemble:
            templates = ENSEMBLE_TEMPLATES[cfg.DATASET.NAME]
            print('=> using prompt ensemble')
            num_temp = len(templates)
            print(f"Prompt ensembling (n={num_temp})")

            mean_text_features = 0
            with torch.no_grad():
                for i, temp in enumerate(templates):
                    prompts = [temp.format(c.replace("_", " ")) for c in classnames]
                    prompts = torch.cat([clip.tokenize(p)
                                        for p in prompts]).to(self.device)
                    text_features = clip_model.encode_text(prompts)
                    text_features = text_features / text_features.norm(dim=-1,
                                                                    keepdim=True)
                    mean_text_features = mean_text_features + text_features
                mean_text_features = mean_text_features / num_temp
                mean_text_features = mean_text_features / mean_text_features.norm(
                    dim=-1, keepdim=True)
            self.text_features = mean_text_features
        else:
            temp = CUSTOM_TEMPLATES[cfg.DATASET.NAME]
            prompts = [temp.format(c.replace("_", " ")) for c in classnames]
            print(f"Prompts: {prompts}")
            prompts = torch.cat([clip.tokenize(p) for p in prompts])
            prompts = prompts.to(self.device)

            with torch.no_grad():
                text_features = clip_model.encode_text(prompts)
                text_features = text_features / text_features.norm(dim=-1,
                                                                keepdim=True)

            self.text_features = text_features / text_features.norm(dim=-1,
                                                            keepdim=True)

        self.clip_model = clip_model
        test_features, test_labels = load_features(cfg, 'test', clip_model, self.test_loader) 
        self.test_features = test_features / test_features.norm(dim=-1,
                                                           keepdim=True)
        self.test_labels = test_labels

    @torch.no_grad()
    def compute_confidence(self, T):
        logit_scale = self.clip_model.logit_scale.exp()
        logits = logit_scale * self.test_features @ self.text_features.t()
        logits /= T # N x K
        probability = F.softmax(logits, dim=-1)
        confidence, _ = torch.max(probability, dim=-1)
        confidence = confidence.mean().item()

        return 100 * confidence

    @torch.no_grad()
    def binary_search(self, accuracy, threshold=1e-2):
        print(f"seach for best T calibrated for accuracy: {accuracy:.2f}%")
        T_min = 0.1
        T_max = 10

        T_best = self.binary_search_recurse(T_min, T_max, accuracy, threshold)

        return T_best

    @torch.no_grad()
    def binary_search_recurse(self, T_min, T_max, accuracy, threshold=1e-1):
        conf_min = self.compute_confidence(T_min)
        gap_min = abs(conf_min - accuracy)

        conf_max = self.compute_confidence(T_max)
        gap_max = abs(conf_max - accuracy)

        print(f"=> T_left  {T_min:.4f} confidence {conf_min:.2f}% gap {gap_min:.2f}"
              f" T_right {T_max:.4f} confidence {conf_max:.2f}% gap {gap_max:.2f}")

        alpha = gap_min / (gap_min + gap_max)
        T_mid = T_min * (1 - alpha) + T_max * alpha
        conf_mid = self.compute_confidence(T_mid)
        gap_mid = abs(conf_mid - accuracy)
        print(f"=> verifying T: {T_mid:.4f} confidence: {conf_mid:.2f}% gap: {gap_mid:.2f}")

        if gap_mid <= threshold:
            print(f"=> done! best T is {T_mid:.4f} with confidence: {conf_mid:.2f}")
            return T_mid

        if conf_max > accuracy:
            T_max *= 1.1
        elif conf_min < accuracy:
            T_min /= 1.1
        elif gap_min < gap_max:
            T_max = T_mid
        else:
            T_min = T_mid

        return self.binary_search_recurse(T_min, T_max, accuracy, threshold)
    
    @torch.no_grad()
    def test(self, split=None):
        """A generic testing pipeline."""
        self.set_model_mode("eval")

        if split is None:
            split = self.cfg.TEST.SPLIT

        print(f"Do evaluation on {split} set")
        logit_scale = self.clip_model.logit_scale.exp()
        outputs = logit_scale * self.test_features @ self.text_features.t() 
        acc = compute_accuracy(outputs, self.test_labels)[0].item()

        print(f"* accuracy: {acc:.2f}%")

        self.binary_search(acc, threshold=0.1)
        return acc


@TRAINER_REGISTRY.register()
class PpSolver(CalibratedZeroshotCLIP):
    def build_model(self):
        super().build_model()         
        self.T = self.cfg.DATASET.T

    def test(self, split=None):
        """A generic testing pipeline."""
        self.set_model_mode("eval")

        if split is None:
            split = self.cfg.TEST.SPLIT

        print(f"Do evaluation on {split} set")
        with torch.no_grad():
            logit_scale = self.clip_model.logit_scale.exp()
            T = self.T
            outputs = logit_scale * self.test_features @ self.text_features.t()/T
            acc = compute_accuracy(outputs, self.test_labels)[0].item()
        print(f"* accuracy: {acc:.2f}%")

        print("=> after finding P_p")
        test_labels = self.test_labels
        pp = pp_solver(outputs, test_labels)
        outputs -= torch.log(pp).to(outputs.device)
        acc = compute_accuracy(outputs, self.test_labels)[0].item()
        print(f"* accuracy: {acc:.2f}%")

        save_dir = osp.join("cache", self.cfg.DATASET.NAME, self.cfg.MODEL.BACKBONE.NAME)
        print(f"=> save results to {save_dir}")
        if not osp.exists(save_dir):
            os.makedirs(save_dir)
        torch.save(pp.cpu().detach().data, osp.join(save_dir, 'pt_prior.pt'))
        return acc