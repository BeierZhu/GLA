import os
import os.path as osp

import torch
import torch.nn as nn
from torch.nn import functional as F
import numpy as np
from tqdm import tqdm

from torch.nn.modules.loss import _Loss
from clip import clip
from dassl.metrics import compute_accuracy

import cooper


class PPCMP(cooper.ConstrainedMinimizationProblem):
    def __init__(self):
        super().__init__(is_constrained=True)
    
    def closure(self, pp, logits, labels):
        pp_logits = logits - torch.log(pp).to(logits.device)
        loss = F.cross_entropy(pp_logits, labels)

        ineq_defect = -pp
        eq_defect = (1- torch.sum(pp))

        return cooper.CMPState(loss=loss, eq_defect=eq_defect, ineq_defect=ineq_defect)


def pp_solver(logits, labels):
    pp = nn.Parameter(torch.ones(logits.size(1))/logits.size(1))

    pp_cmp = PPCMP()
    formulation = cooper.LagrangianFormulation(pp_cmp)
    n_shots = logits.size(0)/logits.size(1)
    lr = 1e-5 * n_shots / 50
    primal_optimizer = torch.optim.SGD([pp], lr=lr)
    dual_optimizer = cooper.optim.partial_optimizer(torch.optim.SGD, lr=lr)
    constrained_optimizer = cooper.ConstrainedOptimizer(formulation, primal_optimizer, dual_optimizer)

    for iter_num in range(1000):
        constrained_optimizer.zero_grad()
        lagrangian = formulation.composite_objective(pp_cmp.closure, pp, logits, labels)
        formulation.custom_backward(lagrangian)
        constrained_optimizer.step(pp_cmp.closure, pp, logits, labels)
    
    return pp


CUSTOM_TEMPLATES = {
    "OxfordPets": "a type of pet, a photo of a {}.",
    "OxfordFlowers": "a type of flower, a photo of a {}.",
    "FGVCAircraft": "a type of aircraft, a photo of a {}",
    "DescribableTextures": "a texture of {}.",
    "EuroSAT": "a centered satellite photo of {}.",
    "StanfordCars": "a photo of a {}.",
    "Food101": "a type of food, a photo of {}.",
    "SUN397": "a photo of a {}.",
    "Caltech101": "a photo of a {}.",
    "UCF101": "a photo of a person doing {}.",
    "ImageNet": "a photo of a {}.",
    "ImageNetLT": "a photo of a {}.",
    "ImageNetSketch": "a photo of a {}.",
    "ImageNetV2": "a photo of a {}.",
    "ImageNetA": "a photo of a {}.",
    "ImageNetR": "a photo of a {}.",
    "Cifar10": "a photo of a {}.",
    "Cifar100": "a photo of a {}.",
}

IMAGENET_TEMPLATES = [
    "a bad photo of a {}.",
    "a photo of many {}.",
    "a sculpture of a {}.",
    "a photo of the hard to see {}.",
    "a low resolution photo of the {}.",
    "a rendering of a {}.",
    "graffiti of a {}.",
    "a bad photo of the {}.",
    "a cropped photo of the {}.",
    "a tattoo of a {}.",
    "the embroidered {}.",
    "a photo of a hard to see {}.",
    "a bright photo of a {}.",
    "a photo of a clean {}.",
    "a photo of a dirty {}.",
    "a dark photo of the {}.",
    "a drawing of a {}.",
    "a photo of my {}.",
    "the plastic {}.",
    "a photo of the cool {}.",
    "a close-up photo of a {}.",
    "a black and white photo of the {}.",
    "a painting of the {}.",
    "a painting of a {}.",
    "a pixelated photo of the {}.",
    "a sculpture of the {}.",
    "a bright photo of the {}.",
    "a cropped photo of a {}.",
    "a plastic {}.",
    "a photo of the dirty {}.",
    "a jpeg corrupted photo of a {}.",
    "a blurry photo of the {}.",
    "a photo of the {}.",
    "a good photo of the {}.",
    "a rendering of the {}.",
    "a {} in a video game.",
    "a photo of one {}.",
    "a doodle of a {}.",
    "a close-up photo of the {}.",
    "a photo of a {}.",
    "the origami {}.",
    "the {} in a video game.",
    "a sketch of a {}.",
    "a doodle of the {}.",
    "a origami {}.",
    "a low resolution photo of a {}.",
    "the toy {}.",
    "a rendition of the {}.",
    "a photo of the clean {}.",
    "a photo of a large {}.",
    "a rendition of a {}.",
    "a photo of a nice {}.",
    "a photo of a weird {}.",
    "a blurry photo of a {}.",
    "a cartoon {}.",
    "art of a {}.",
    "a sketch of the {}.",
    "a embroidered {}.",
    "a pixelated photo of a {}.",
    "itap of the {}.",
    "a jpeg corrupted photo of the {}.",
    "a good photo of a {}.",
    "a plushie {}.",
    "a photo of the nice {}.",
    "a photo of the small {}.",
    "a photo of the weird {}.",
    "the cartoon {}.",
    "art of the {}.",
    "a drawing of the {}.",
    "a photo of the large {}.",
    "a black and white photo of a {}.",
    "the plushie {}.",
    "a dark photo of a {}.",
    "itap of a {}.",
    "graffiti of the {}.",
    "a toy {}.",
    "itap of my {}.",
    "a photo of a cool {}.",
    "a photo of a small {}.",
    "a tattoo of the {}.",
]


ENSEMBLE_TEMPLATES = {
    "Caltech101": IMAGENET_TEMPLATES,
    "ImageNet": IMAGENET_TEMPLATES,
    "ImageNetA": IMAGENET_TEMPLATES,
    "ImageNetR": IMAGENET_TEMPLATES,
    "ImageNetV2": IMAGENET_TEMPLATES,
    "ImageNetLT": IMAGENET_TEMPLATES,
    "SUN397": IMAGENET_TEMPLATES,
    "ImageNetSketch": IMAGENET_TEMPLATES,
    "UCF101": [CUSTOM_TEMPLATES["UCF101"]],
    "OxfordPets": [CUSTOM_TEMPLATES["OxfordPets"]],
    "EuroSAT": [CUSTOM_TEMPLATES["EuroSAT"]],
    "Food101": [CUSTOM_TEMPLATES["Food101"]],
    "OxfordFlowers": [CUSTOM_TEMPLATES["OxfordFlowers"]],
    "FGVCAircraft": ["a photo of a {}, a type of aircraft."],
    "DescribableTextures": ["{} texture."],
    "StanfordCars": ["a photo of a {}."],
}

# research best T for model calibration
# acc: %
# model: has function inference
class Calibrater:
    def __init__(self, model, acc):
        self.model = model
        self.acc = acc
    
    @torch.no_grad()
    def compute_confidence(self, features, T):
        logits = self.model.inference(features) / T
        probability = F.softmax(logits, dim=-1)
        confidence, _ = torch.max(probability, dim=-1)
        confidence = confidence.mean().item()

        return 100 * confidence
    
    def search_T(self, features, acc, thres=0.1):
        T_min, T_max = 0.1, 10
        T_best, confidence = self.search_recurse(features, T_min, T_max, acc, thres)

        print(f"=> T {T_best:.4f} confidence {confidence:.2f}% accuracy {acc:.2f}% ")
        return T_best, confidence

    @torch.no_grad()
    def search_recurse(self, features, T_min, T_max, acc, thres):
        conf_min = self.compute_confidence(features, T_min)
        gap_min = abs(conf_min - acc)

        conf_max = self.compute_confidence(features, T_max)
        gap_max = abs(conf_max - acc)

        alpha = gap_min / (gap_min + gap_max)
        T_mid = T_min * (1 - alpha) + T_max * alpha
        conf_mid = self.compute_confidence(features, T_mid)
        gap_mid = abs(conf_mid - acc)

        if gap_mid <= thres:
            return T_mid, conf_mid

        if conf_max > acc:
            T_max *= 1.1
        elif conf_min < acc:
            T_min /= 1.1
        elif gap_min < gap_max:
            T_max = T_mid
        else:
            T_min = T_mid

        return self.search_recurse(features, T_min, T_max, acc, thres)


# since prompt tuning does not affect visual backbone, 
# save validation and test set in advance for fast inference
def load_features(cfg, split, clip_model, loader):
    cache_dir = osp.join(cfg.DATASET.CACHE_DIR, cfg.DATASET.NAME)
    backbone_name = cfg.MODEL.BACKBONE.NAME
    n_shot = cfg.DATASET.NUM_SHOTS
    seed = cfg.SEED

    if split == "test":
        features_path = osp.join(cache_dir, f'{backbone_name}_{split}_features.pt')
        labels_path = osp.join(cache_dir, f'{backbone_name}_{split}_labels.pt')
    else:
        features_path = osp.join(cache_dir, f'{backbone_name}_{split}_{n_shot}_{seed}_features.pt')
        labels_path = osp.join(cache_dir, f'{backbone_name}_{split}_{n_shot}_{seed}_labels.pt')

    if osp.exists(features_path) and osp.exists(labels_path):
        print(f"=> load {split} features and labels from {cache_dir}")
        features = torch.load(features_path)
        labels = torch.load(labels_path)
    else:
        clip_model.cuda()
        features = []
        labels = []

        with torch.no_grad():
            for batch in tqdm(loader):
                image = batch["img"]
                label = batch["label"]
                image = image.cuda()
                label = label.cuda()

                feature = clip_model.encode_image(image)
                feature /= feature.norm(dim=-1, keepdim=True)

                features.append(feature)
                labels.append(label)

        features = torch.cat(features)
        labels = torch.cat(labels)
        if not osp.exists(cache_dir):
            os.makedirs(cache_dir)

        print(f'=> save {split} features and labels to {cache_dir}')
        torch.save(features, features_path)
        torch.save(labels, labels_path)

    return features, labels


class KL(_Loss):
    def __init__(self, T=1):
        super(KL, self).__init__()
        self.T = T

    def forward(self, stu_logits, tea_logits):
        tea_prob = F.softmax(tea_logits / self.T, dim=-1)
        kl_loss = -tea_prob * F.log_softmax(stu_logits / self.T,
                                            -1) * self.T * self.T
        # this is an offset
        kl_loss += tea_prob * F.log_softmax(tea_logits / self.T,
                                            -1) * self.T * self.T
        kl_loss = kl_loss.sum(1).mean()

        return kl_loss

def load_clip_to_cpu(cfg):
    backbone_name = cfg.MODEL.BACKBONE.NAME
    url = clip._MODELS[backbone_name]
    model_path = clip._download(url)

    try:
        # loading JIT archive
        model = torch.jit.load(model_path, map_location="cpu").eval()
        state_dict = None

    except RuntimeError:
        state_dict = torch.load(model_path, map_location="cpu")

    model = clip.build_model(state_dict or model.state_dict())

    return model


class TextEncoder(nn.Module):
    def __init__(self, clip_model):
        super().__init__()
        self.transformer = clip_model.transformer
        self.positional_embedding = clip_model.positional_embedding
        self.ln_final = clip_model.ln_final
        self.text_projection = clip_model.text_projection
        self.dtype = clip_model.dtype

    def forward(self, prompts, tokenized_prompts):
        x = prompts + self.positional_embedding.type(self.dtype)
        x = x.permute(1, 0, 2)  # NLD -> LND
        x = self.transformer(x)
        x = x.permute(1, 0, 2)  # LND -> NLD
        x = self.ln_final(x).type(self.dtype)

        # x.shape = [batch_size, n_ctx, transformer.width]
        # take features from the eot embedding (eot_token is the highest number in each sequence)
        x = x[torch.arange(x.shape[0]),
              tokenized_prompts.argmax(dim=-1)] @ self.text_projection

        return x


class CLIP(nn.Module):
    def __init__(self, cfg, classnames, use_ensemble=False):
        super().__init__()
        print(f"Loading CLIP (backbone: {cfg.MODEL.BACKBONE.NAME})")
        clip_model = load_clip_to_cpu(cfg)
        if torch.cuda.is_available() and cfg.USE_CUDA:
            self.device = torch.device("cuda")
        else:
            self.device = torch.device("cpu")
        clip_model.to(self.device)
        dtype = clip_model.dtype

        if use_ensemble:
            templates = ENSEMBLE_TEMPLATES[cfg.DATASET.NAME]
            print('=> using prompt ensemble')
            num_temp = len(templates)
            print(f"Prompt ensembling (n={num_temp})")

            mean_text_features = 0
            with torch.no_grad():
                for i, temp in enumerate(templates):
                    prompts = [temp.format(c.replace("_", " ")) for c in classnames]
                    prompts = torch.cat([clip.tokenize(p)
                                        for p in prompts]).to(self.device)
                    text_features = clip_model.encode_text(prompts)
                    text_features = text_features / text_features.norm(dim=-1,
                                                                    keepdim=True)
                    mean_text_features = mean_text_features + text_features
                mean_text_features = mean_text_features / num_temp
                mean_text_features = mean_text_features / mean_text_features.norm(
                    dim=-1, keepdim=True)
            self.text_features = mean_text_features
        else:
            temp = CUSTOM_TEMPLATES[cfg.DATASET.NAME]
            prompts = [temp.format(c.replace("_", " ")) for c in classnames]
            print(f"Prompts: {prompts}")
            prompts = torch.cat([clip.tokenize(p) for p in prompts])

            with torch.no_grad():
                text_features = clip_model.encode_text(prompts.to(self.device))
                text_features = text_features / text_features.norm(dim=-1,
                                                                keepdim=True)

            self.text_features = text_features
        self.clip_model = clip_model
        self.T = cfg.DATASET.T
        self.cfg = cfg

    def forward(self, image):
        image_features = self.clip_model.encode_image(image)
        image_features = image_features / image_features.norm(dim=-1,
                                                              keepdim=True)
        logit_scale = self.clip_model.logit_scale.exp()
        T = self.T

        text_features = self.text_features
        text_features = text_features.to(image_features.device)
        logits = logit_scale * image_features @ text_features.t()
        logits /= T

        return logits
    
    def inference(self, image_features):
        logit_scale = self.clip_model.logit_scale.exp()
        T = self.T

        text_features = self.text_features
        text_features = text_features.to(image_features.device)

        logits = logit_scale * image_features @ text_features.t()
        logits /= T

        return logits
    
    def pp_estimate(self, features, labels):
        pp_path = osp.join("cache", self.cfg.DATASET.NAME, self.cfg.MODEL.BACKBONE.NAME, 'pt_prior.pt')

        if osp.exists(pp_path):
            pp = torch.load(pp_path)
        else:
            print(f"Estimating q from validation set...")
            with torch.no_grad():
                outputs = self.inference(features)
            acc = compute_accuracy(outputs, labels)[0].item()
            calibrater = Calibrater(self, acc)
            T, _ = calibrater.search_T(features, acc)
            self.T = T
            outputs /= T

            pp = pp_solver(outputs, labels)

            print("=> after estimating P_p")
            outputs -= torch.log(pp).to(outputs.device)
            acc = compute_accuracy(outputs, labels)[0].item()
            print(f"* accuracy: {acc:.2f}%")

        return pp
        

def shot_acc(preds, labels, train_data, many_shot_thr=100, low_shot_thr=20, acc_per_cls=False):
    training_labels = np.array(train_data).astype(int)

    if isinstance(preds, torch.Tensor):
        preds = preds.detach().cpu().numpy()
        labels = labels.detach().cpu().numpy()
    elif isinstance(preds, np.ndarray):
        pass
    else:
        raise TypeError('Type ({}) of preds not supported'.format(type(preds)))

    train_class_count = []
    test_class_count = []
    class_correct = []
    for l in np.unique(labels):
        train_class_count.append(len(training_labels[training_labels == l]))
        test_class_count.append(len(labels[labels == l]))
        class_correct.append((preds[labels == l] == labels[labels == l]).sum())

    many_shot = []
    median_shot = []
    low_shot = []
    for i in range(len(train_class_count)):
        if train_class_count[i] > many_shot_thr:
            many_shot.append((class_correct[i] / test_class_count[i]))
        elif train_class_count[i] < low_shot_thr:
            low_shot.append((class_correct[i] / test_class_count[i]))
        else:
            median_shot.append((class_correct[i] / test_class_count[i]))

    if len(many_shot) == 0:
        many_shot.append(0)
    if len(median_shot) == 0:
        median_shot.append(0)
    if len(low_shot) == 0:
        low_shot.append(0)

    if acc_per_cls:
        class_accs = [c / cnt for c, cnt in zip(class_correct, test_class_count)]
        return np.mean(many_shot), np.mean(median_shot), np.mean(low_shot), class_accs
    else:
        class_accs = [c / cnt for c, cnt in zip(class_correct, test_class_count)]
        return np.mean(many_shot), np.mean(median_shot), np.mean(low_shot), np.mean(class_accs)