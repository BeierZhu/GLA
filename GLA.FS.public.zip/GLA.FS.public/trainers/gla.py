import os.path as osp

import torch
import torch.nn as nn
from torch.nn import functional as F
from torch.cuda.amp import GradScaler, autocast

import numpy as np
from tqdm import tqdm

from dassl.engine import TRAINER_REGISTRY, TrainerX
from dassl.metrics import compute_accuracy
from dassl.utils import load_pretrained_weights, load_checkpoint
from dassl.optim import build_optimizer, build_lr_scheduler

from clip import clip
from clip.simple_tokenizer import SimpleTokenizer as _Tokenizer
from .util import CUSTOM_TEMPLATES, CLIP, load_features, Calibrater
import copy
_tokenizer = _Tokenizer()


def load_clip_to_cpu(cfg):
    backbone_name = cfg.MODEL.BACKBONE.NAME
    url = clip._MODELS[backbone_name]
    model_path = clip._download(url)

    try:
        # loading JIT archive
        model = torch.jit.load(model_path, map_location="cpu").eval()
        state_dict = None

    except RuntimeError:
        state_dict = torch.load(model_path, map_location="cpu")

    model = clip.build_model(state_dict or model.state_dict())

    return model


class TextEncoder(nn.Module):
    def __init__(self, clip_model):
        super().__init__()
        self.transformer = clip_model.transformer
        self.positional_embedding = clip_model.positional_embedding
        self.ln_final = clip_model.ln_final
        self.text_projection = clip_model.text_projection
        self.dtype = clip_model.dtype

    def forward(self, prompts, tokenized_prompts):
        x = prompts + self.positional_embedding.type(self.dtype)
        x = x.permute(1, 0, 2)  # NLD -> LND
        x = self.transformer(x)
        x = x.permute(1, 0, 2)  # LND -> NLD
        x = self.ln_final(x).type(self.dtype)

        # x.shape = [batch_size, n_ctx, transformer.width]
        # take features from the eot embedding (eot_token is the highest number in each sequence)
        x = x[torch.arange(x.shape[0]),
              tokenized_prompts.argmax(dim=-1)] @ self.text_projection

        return x


class PromptLearner(nn.Module):
    def __init__(self, cfg, classnames, clip_model):
        super().__init__()
        n_cls = len(classnames)
        dtype = clip_model.dtype
        ctx_dim = clip_model.ln_final.weight.shape[0]
        clip_imsize = clip_model.visual.input_resolution
        cfg_imsize = cfg.INPUT.SIZE[0]
        assert cfg_imsize == clip_imsize, f"cfg_imsize ({cfg_imsize}) must equal to clip_imsize ({clip_imsize})"

        ctx_init = CUSTOM_TEMPLATES[cfg.DATASET.NAME]
        ctx_init = ctx_init.replace(" {}.", "")
        ctx_init = ctx_init.replace("_", " ")
        prompt_n_ctx = len(ctx_init.split(" "))

        print(f'Initial context: "{ctx_init}"')

        classnames = [name.replace("_", " ") for name in classnames]
        name_lens = [len(_tokenizer.encode(name)) for name in classnames]
        prompts = [ctx_init + " " + name + "." for name in classnames]
        tokenized_prompts = torch.cat([clip.tokenize(p) for p in prompts])

        with torch.no_grad():
            embedding = clip_model.token_embedding(tokenized_prompts).type(
                dtype)

        # These token vectors will be saved when in save_model(),
        # but they should be ignored in load_model() as we want to use
        # those computed using the current class names
        self.register_buffer("token_prefix", embedding[:, :1, :])  # SOS
        self.register_buffer("ctx", embedding[:, 1:1 + prompt_n_ctx, :]) # Prompt
        self.register_buffer("cls_token", embedding[:, 1 + prompt_n_ctx:-1, :]) # CLS
        self.register_buffer("token_suffix", embedding[:, -1:, :])  # EOS

        res_cls_token = torch.zeros_like(self.cls_token, dtype=dtype)
        self.res_cls_token = nn.Parameter(res_cls_token)

        res_ctx_token = torch.zeros_like(self.ctx, dtype=dtype)
        self.res_ctx_token = nn.Parameter(res_ctx_token)

        self.n_cls = n_cls
        self.tokenized_prompts = tokenized_prompts  # torch.Tensor
        self.name_lens = name_lens
        self.class_token_position = cfg.TRAINER.COOP.CLASS_TOKEN_POSITION

    def forward(self):
        ctx = self.ctx
        cls_token = self.cls_token
        prefix = self.token_prefix
        suffix = self.token_suffix
        res_cls_token = self.res_cls_token
        res_ctx_token = self.res_ctx_token

        ctx = ctx.to(prefix)

        prompts = torch.cat(
            [
                prefix,  # (n_cls, 1, dim)
                ctx + res_ctx_token,  # (n_cls, prompt_n_ctx, dim)
                cls_token + res_cls_token, # (n_cls, *, dim)
                suffix,  # (n_cls, 1, dim)
            ],
            dim=1,
        )
     
        return prompts


class CustomCLIP(nn.Module):
    def __init__(self, cfg, classnames, clip_model):
        super().__init__()
        self.prompt_learner = PromptLearner(cfg, classnames, clip_model)
        self.tokenized_prompts = self.prompt_learner.tokenized_prompts
        self.image_encoder = clip_model.visual
        self.text_encoder = TextEncoder(clip_model)
        self.logit_scale = clip_model.logit_scale
        self.dtype = clip_model.dtype

    def forward(self, image, return_feat=False):
        image_features = self.image_encoder(image.type(self.dtype))

        prompts = self.prompt_learner()
        tokenized_prompts = self.tokenized_prompts
        text_features = self.text_encoder(prompts, tokenized_prompts)

        image_features = image_features / image_features.norm(dim=-1,
                                                              keepdim=True)
        text_features = text_features / text_features.norm(dim=-1,
                                                           keepdim=True)

        logit_scale = self.logit_scale.exp()
        logits = logit_scale * image_features @ text_features.t()

        if return_feat:
            return logits, image_features
        else:
            return logits

    @torch.no_grad()
    def inference(self, image_features):
        prompts = self.prompt_learner()
        tokenized_prompts = self.tokenized_prompts
        text_features = self.text_encoder(prompts, tokenized_prompts)
        text_features = text_features / text_features.norm(dim=-1,
                                                           keepdim=True)

        logit_scale = self.logit_scale.exp()
        logits = logit_scale * image_features @ text_features.t()

        return logits


@TRAINER_REGISTRY.register()
class GLA(TrainerX):
    """Generalized Logit Adjustment
    """
    def check_cfg(self, cfg):
        assert cfg.TRAINER.COOP.PREC in ["fp16", "fp32", "amp"]

    def build_model(self):
        cfg = self.cfg
        classnames = self.dm.dataset.classnames

        print(f"Loading CLIP (backbone: {cfg.MODEL.BACKBONE.NAME})")
        clip_model = load_clip_to_cpu(cfg)

        if cfg.TRAINER.COOP.PREC == "fp32" or cfg.TRAINER.COOP.PREC == "amp":
            # CLIP's default precision is fp16
            clip_model.float()

        print("Building zeroshot CLIP")
        self.zs_clip = CLIP(cfg, classnames, use_ensemble=True)

        print("Building custom CLIP")
        self.model = CustomCLIP(cfg, classnames, clip_model)

        print("Turning off gradients in both the image and the text encoder")
        for name, param in self.model.named_parameters():
            if "prompt_learner" not in name:
                param.requires_grad_(False)

        # load val and test features for fast inference
        self.train_features, self.train_labels = load_features(cfg, 'train', clip_model, self.train_loader_no_aug) 
        self.val_features, self.val_labels = load_features(cfg, 'val', clip_model, self.val_loader) 
        self.test_features, self.test_labels = load_features(cfg, 'test', clip_model, self.test_loader) 

        # concate train and val data for find P_p in few-shot learning
        # as we do not have much val data, additionally using train data
        if cfg.DATASET.NUM_SHOTS < 20:
            features = torch.cat([self.train_features, self.val_features], dim=0)
            labels = torch.cat([self.train_labels, self.val_labels], dim=0)
        else:
            features = self.val_features
            labels = self.val_labels
            
        self.pt_prior = self.zs_clip.pp_estimate(features, labels)

        self.model.to(self.device)
        # NOTE: only give prompt_learner to the optimizer
        batch_size = cfg.DATALOADER.TRAIN_X.BATCH_SIZE
        num_train = len(classnames) * cfg.DATASET.NUM_SHOTS
        if num_train < batch_size:
            cfg.defrost()
            cfg.OPTIM.LR = cfg.OPTIM.LR * (batch_size/num_train)
            cfg.freeze()
            assert cfg.DATASET.NAME == "EuroSAT"
            print(f"number of training samples is not enought to construct a batch, adjust learning rate")

        self.optim = build_optimizer(self.model.prompt_learner, cfg.OPTIM)
        self.sched = build_lr_scheduler(self.optim, cfg.OPTIM)
        self.register_model("prompt_learner", self.model.prompt_learner,
                            self.optim, self.sched)

        self.scaler = GradScaler() if cfg.TRAINER.COOP.PREC == "amp" else None

        # Note that multi-gpu training could be slow because CLIP's size is
        # big, which slows down the copy operation in DataParallel
        device_count = torch.cuda.device_count()
        if device_count > 1:
            print(
                f"Multiple GPUs detected (n_gpus={device_count}), use all of them!"
            )
            self.model.text_encoder = nn.DataParallel(self.model.text_encoder)
        
    def forward_backward(self, batch):
        image, label = self.parse_batch_train(batch)
        output, features = self.model(image, return_feat=True)

        loss = F.cross_entropy(output, label)
        self.model_backward_and_update(loss)

        loss_summary = {
            "loss": loss.item(),
            "acc": compute_accuracy(output, label)[0].item(),
        }

        if (self.batch_idx + 1) == self.num_batches:
            self.update_lr()

        return loss_summary

    def parse_batch_train(self, batch):
        input = batch["img"]
        label = batch["label"]
        input = input.to(self.device)
        label = label.to(self.device)
        return input, label

    @torch.no_grad()
    def post_hoc_gla(self, outputs, zs_outputs, pt_prior):
        return outputs + zs_outputs - torch.log(pt_prior + 1e-12).to(outputs.device)

    @torch.no_grad()
    def test(self, split=None):
        self.set_model_mode("eval")

        if split is None:
            split = self.cfg.TEST.SPLIT

        print(f"Do evaluation on val set")
        outputs = self.model.inference(self.val_features)
        acc = compute_accuracy(outputs, self.val_labels)[0].item()
        print(f"* erm accuracy: {acc:.2f}%")
        # calibrated for erm model
        calibrater = Calibrater(self.model, acc)
        T, _ = calibrater.search_T(self.val_features, acc, thres=1.)
        outputs /= T

        zs_outputs = self.zs_clip.inference(self.val_features)
        gla_outputs = self.post_hoc_gla(outputs, zs_outputs, self.pt_prior)
        acc = compute_accuracy(gla_outputs, self.val_labels)[0].item()
        print(f"* gla accuracy: {acc:.2f}%")

        if split == 'test':
            print(f"Do evaluation on test set")
            outputs = self.model.inference(self.test_features)
            acc = compute_accuracy(outputs, self.test_labels)[0].item()
            print(f"* erm accuracy: {acc:.2f}%")

            outputs /= T
            zs_outputs = self.zs_clip.inference(self.test_features)
            gla_outputs = self.post_hoc_gla(outputs, zs_outputs, self.pt_prior)
            acc = compute_accuracy(gla_outputs, self.test_labels)[0].item()
            print(f"* gla accuracy: {acc:.2f}%")

        return acc

    def load_model(self, directory, epoch=None):
        if not directory:
            print(
                "Note that load_model() is skipped as no pretrained model is given"
            )
            return

        names = self.get_model_names()

        # By default, the best model is loaded
        model_file = "model-best.pth.tar"

        if epoch is not None:
            model_file = "model.pth.tar-" + str(epoch)

        for name in names:
            model_path = osp.join(directory, name, model_file)

            if not osp.exists(model_path):
                raise FileNotFoundError(
                    'Model not found at "{}"'.format(model_path))

            checkpoint = load_checkpoint(model_path)
            state_dict = checkpoint["state_dict"]
            epoch = checkpoint["epoch"]

            # Ignore fixed token vectors
            if "token_prefix" in state_dict:
                del state_dict["token_prefix"]

            if "token_suffix" in state_dict:
                del state_dict["token_suffix"]

            # activate for ImageNet ood testing, ood classes might be a subset of source labels
            if hasattr(self.dm.dataset, "all_labels"): 
                all_labels = self.dm.dataset.all_labels
                state_dict["res_cls_token"] = state_dict["res_cls_token"][all_labels,]
                state_dict["res_ctx_token"] = state_dict["res_ctx_token"][all_labels,]
                state_dict["cls_token"] = state_dict["cls_token"][all_labels,]
                state_dict["ctx"] = state_dict["ctx"][all_labels,]

            print("Loading weights to {} "
                  'from "{}" (epoch = {})'.format(name, model_path, epoch))
            # set strict=False
            self._models[name].load_state_dict(state_dict, strict=False)
