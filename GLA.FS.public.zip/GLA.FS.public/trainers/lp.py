import os.path as osp
import pickle
import torch
import torch.nn as nn
from torch.nn import functional as F
from torch.cuda.amp import GradScaler, autocast

import numpy as np
from tqdm import tqdm

from dassl.engine import TRAINER_REGISTRY, TrainerX
from dassl.metrics import compute_accuracy
from dassl.utils import load_pretrained_weights, load_checkpoint
from dassl.optim import build_optimizer, build_lr_scheduler

from clip import clip
from clip.simple_tokenizer import SimpleTokenizer as _Tokenizer
from .util import CUSTOM_TEMPLATES, CLIP, load_features, Calibrater
import copy
_tokenizer = _Tokenizer()


def load_clip_to_cpu(cfg):
    backbone_name = cfg.MODEL.BACKBONE.NAME
    url = clip._MODELS[backbone_name]
    model_path = clip._download(url)

    try:
        # loading JIT archive
        model = torch.jit.load(model_path, map_location="cpu").eval()
        state_dict = None

    except RuntimeError:
        state_dict = torch.load(model_path, map_location="cpu")

    model = clip.build_model(state_dict or model.state_dict())

    return model


class CustomCLIP(nn.Module):
    def __init__(self, cfg, classnames, clip_model):
        super().__init__()
        self.image_encoder = clip_model.visual
        self.dtype = clip_model.dtype
        self.classifier = nn.Linear(1024, 1000, dtype=self.dtype)

    def forward(self, image):
        image_features = self.image_encoder(image.type(self.dtype))
        image_features = image_features / image_features.norm(dim=-1,
                                                              keepdim=True)
        logits = self.classifier(image_features)

        return logits

    @torch.no_grad()
    def inference(self, image_features):
        logits = self.classifier(image_features)

        return logits


@TRAINER_REGISTRY.register()
class LP(TrainerX):
    """Linear Probing
    """
    def check_cfg(self, cfg):
        assert cfg.TRAINER.COOP.PREC in ["fp16", "fp32", "amp"]

    def build_model(self):
        cfg = self.cfg
        classnames = self.dm.dataset.classnames

        print(f"Loading CLIP (backbone: {cfg.MODEL.BACKBONE.NAME})")
        clip_model = load_clip_to_cpu(cfg)

        if cfg.TRAINER.COOP.PREC == "fp32" or cfg.TRAINER.COOP.PREC == "amp":
            # CLIP's default precision is fp16
            clip_model.float()

        print("Building zeroshot CLIP")
        self.zs_clip = CLIP(cfg, classnames, use_ensemble=True)

        print("Building custom CLIP")
        self.model = CustomCLIP(cfg, classnames, clip_model)

        print("Turning off gradients in both the image and the text encoder")
        for name, param in self.model.named_parameters():
            if "classifier" not in name:
                param.requires_grad_(False)

        # load val and test features for fast inference
        self.train_features, self.train_labels = load_features(cfg, 'train', clip_model, self.train_loader_no_aug) 
        self.val_features, self.val_labels = load_features(cfg, 'val', clip_model, self.val_loader) 
        self.test_features, self.test_labels = load_features(cfg, 'test', clip_model, self.test_loader) 

        # concate train and val data for find P_p in few-shot learning
        # as we do not have much val data, additionally using train data
        if cfg.DATASET.NUM_SHOTS < 20:
            features = torch.cat([self.train_features, self.val_features], dim=0)
            labels = torch.cat([self.train_labels, self.val_labels], dim=0)
        else:
            features = self.val_features
            labels = self.val_labels
            
        self.pt_prior = self.zs_clip.pp_estimate(features, labels)

        self.model.to(self.device)

        self.optim = build_optimizer(self.model.classifier, cfg.OPTIM)
        self.sched = build_lr_scheduler(self.optim, cfg.OPTIM)
        self.register_model("classifier", self.model.classifier,
                            self.optim, self.sched)

        self.scaler = GradScaler() if cfg.TRAINER.COOP.PREC == "amp" else None

        # Note that multi-gpu training could be slow because CLIP's size is
        # big, which slows down the copy operation in DataParallel
        device_count = torch.cuda.device_count()
        if device_count > 1:
            print(
                f"Multiple GPUs detected (n_gpus={device_count}), use all of them!"
            )
            self.model.text_encoder = nn.DataParallel(self.model.text_encoder)
        
    def forward_backward(self, batch):
        image, label = self.parse_batch_train(batch)
        output = self.model(image)

        loss = F.cross_entropy(output, label)
        self.model_backward_and_update(loss)

        loss_summary = {
            "loss": loss.item(),
            "acc": compute_accuracy(output, label)[0].item(),
        }

        if (self.batch_idx + 1) == self.num_batches:
            self.update_lr()

        return loss_summary

    def parse_batch_train(self, batch):
        input = batch["img"]
        label = batch["label"]
        input = input.to(self.device)
        label = label.to(self.device)
        return input, label

    @torch.no_grad()
    def post_hoc_gla(self, outputs, zs_outputs, pt_prior):
        return outputs + zs_outputs - torch.log(pt_prior + 1e-12).to(outputs.device)

    @torch.no_grad()
    def test(self, split=None):
        self.set_model_mode("eval")

        if split == 'val':
            features = self.val_features
            labels = self.val_labels
        else:
            features = self.test_features
            labels = self.test_labels

        print(f"Do evaluation on {split} set")
        outputs = self.model.inference(features)
        acc = compute_accuracy(outputs, labels)[0].item()

        zs_outputs = self.zs_clip.inference(features)
        zs_acc = compute_accuracy(zs_outputs, labels)[0].item()
        print(f"* erm accuracy: {acc:.2f}%")
        print(f"* zs accuracy: {zs_acc:.2f}%")

        if split != 'val':
            save_dict = {}
            save_dict['erm'] = outputs.cpu().numpy()
            save_dict['zs'] = zs_outputs.cpu().numpy()
            save_dict['gt'] = labels.cpu().numpy()

            with open(osp.join(self.cfg.OUTPUT_DIR, 'save.pt'), 'wb') as f:
                pickle.dump(save_dict, f)
            
        return acc

    def load_model(self, directory, epoch=None):
        if not directory:
            print(
                "Note that load_model() is skipped as no pretrained model is given"
            )
            return

        names = self.get_model_names()

        # By default, the best model is loaded
        model_file = "model-best.pth.tar"

        if epoch is not None:
            model_file = "model.pth.tar-" + str(epoch)

        for name in names:
            model_path = osp.join(directory, name, model_file)

            if not osp.exists(model_path):
                raise FileNotFoundError(
                    'Model not found at "{}"'.format(model_path))

            checkpoint = load_checkpoint(model_path)
            state_dict = checkpoint["state_dict"]
            epoch = checkpoint["epoch"]

            # Ignore fixed token vectors
            if "token_prefix" in state_dict:
                del state_dict["token_prefix"]

            if "token_suffix" in state_dict:
                del state_dict["token_suffix"]

            # activate for ImageNet ood testing, ood classes might be a subset of source labels
            if hasattr(self.dm.dataset, "all_labels"): 
                all_labels = self.dm.dataset.all_labels
                state_dict["res_cls_token"] = state_dict["res_cls_token"][all_labels,]
                state_dict["res_ctx_token"] = state_dict["res_ctx_token"][all_labels,]
                state_dict["cls_token"] = state_dict["cls_token"][all_labels,]
                state_dict["ctx"] = state_dict["ctx"][all_labels,]

            print("Loading weights to {} "
                  'from "{}" (epoch = {})'.format(name, model_path, epoch))
            # set strict=False
            self._models[name].load_state_dict(state_dict, strict=False)
