import os.path as osp

import torch
import torch.nn as nn
from torch.nn import functional as F
from torch.cuda.amp import GradScaler, autocast

import numpy as np
from tqdm import tqdm

from dassl.engine import TRAINER_REGISTRY, TrainerX
from dassl.metrics import compute_accuracy
from dassl.utils import load_pretrained_weights, load_checkpoint
from dassl.optim import build_optimizer, build_lr_scheduler

from clip import clip
from clip.simple_tokenizer import SimpleTokenizer as _Tokenizer
from .util import CUSTOM_TEMPLATES, CLIP, load_features, Calibrater
import copy
_tokenizer = _Tokenizer()


def load_clip_to_cpu(cfg):
    backbone_name = cfg.MODEL.BACKBONE.NAME
    url = clip._MODELS[backbone_name]
    model_path = clip._download(url)

    try:
        # loading JIT archive
        model = torch.jit.load(model_path, map_location="cpu").eval()
        state_dict = None

    except RuntimeError:
        state_dict = torch.load(model_path, map_location="cpu")

    model = clip.build_model(state_dict or model.state_dict())

    return model


@TRAINER_REGISTRY.register()
class DebiasedZeroShot(TrainerX):
    def check_cfg(self, cfg):
        assert cfg.TRAINER.COOP.PREC in ["fp16", "fp32", "amp"]

    def build_model(self):
        cfg = self.cfg
        classnames = self.dm.dataset.classnames

        print(f"Loading CLIP (backbone: {cfg.MODEL.BACKBONE.NAME})")
        clip_model = load_clip_to_cpu(cfg)

        if cfg.TRAINER.COOP.PREC == "fp32" or cfg.TRAINER.COOP.PREC == "amp":
            # CLIP's default precision is fp16
            clip_model.float()

        print("Building zeroshot CLIP")
        self.zs_clip = CLIP(cfg, classnames, use_ensemble=True)

        # load val and test features for fast inference
        self.train_features, self.train_labels = load_features(cfg, 'train', clip_model, self.train_loader_no_aug) 
        self.val_features, self.val_labels = load_features(cfg, 'val', clip_model, self.val_loader) 
        self.test_features, self.test_labels = load_features(cfg, 'test', clip_model, self.test_loader) 

        # concate train and val data for find P_p in few-shot learning
        # as we do not have much val data, additionally using train data
        if cfg.DATASET.NUM_SHOTS < 20:
            features = torch.cat([self.train_features, self.val_features], dim=0)
            labels = torch.cat([self.train_labels, self.val_labels], dim=0)
        else:
            features = self.val_features
            labels = self.val_labels
            
        self.pt_prior = self.zs_clip.pp_estimate(features, labels)

    @torch.no_grad()
    def test(self, split=None):
        self.set_model_mode("eval")
        print("Do evaluation on test set")

        zs_outputs = self.zs_clip.inference(self.test_features)
        zs_acc = compute_accuracy(zs_outputs, self.test_labels)[0].item()
        print(f"* zero shot accuracy: {zs_acc:.2f}%")

        debiased_zs_outputs = zs_outputs - torch.log(self.pt_prior + 1e-12).to(zs_outputs.device)
        debiased_zs_acc = compute_accuracy(debiased_zs_outputs, self.test_labels)[0].item()
        print(f"* debiased zero shot accuracy: {debiased_zs_acc:.2f}%")

        return debiased_zs_acc
