# How to install datasets and environment

Please refer [ProGrad](https://github.com/BeierZhu/Prompt-align) to install the environment and set up ImageNet datasets.

# How to run

To run the results on ImageNet few-shot results, please run 

```bash
cd script
bash gla.sh
```

It will automatically run 1, 2, 4, 8, 16 shots training on ImageNet with three random seeds.

# How to evaluate

For example, to evaluate 1 shot results

```bash
python parse_test_res.py output/imagenet/GLA/rn50_ep50_shot1/ --test-log
```

Results output like follwing, 

```
(dassl) beier@micl-zhanghwws24:~/Prompt-align/GLA.FS_LT.public$ python parse_test_res.py output/imagenet/GLA/rn50_ep50_shot1/ --test-log
Parsing files in output/imagenet/GLA/rn50_ep50_shot1/
file: output/imagenet/GLA/rn50_ep50_shot1/seed1/log.txt. gla accuracy: 61.91%. 
file: output/imagenet/GLA/rn50_ep50_shot1/seed2/log.txt. gla accuracy: 61.66%. 
file: output/imagenet/GLA/rn50_ep50_shot1/seed3/log.txt. gla accuracy: 62.04%. 
===
Summary of directory: output/imagenet/GLA/rn50_ep50_shot1/
* gla accuracy: 61.87% +- 0.16%
===
(dassl) beier@micl-zhanghwws24:~/Prompt-align/GLA.FS_LT.public$ python parse_test_res.py output/imagenet/GLA/rn50_ep50_shot2/ --test-log
Parsing files in output/imagenet/GLA/rn50_ep50_shot2/
file: output/imagenet/GLA/rn50_ep50_shot2/seed1/log.txt. gla accuracy: 62.64%. 
file: output/imagenet/GLA/rn50_ep50_shot2/seed2/log.txt. gla accuracy: 62.63%. 
file: output/imagenet/GLA/rn50_ep50_shot2/seed3/log.txt. gla accuracy: 62.66%. 
===
Summary of directory: output/imagenet/GLA/rn50_ep50_shot2/
* gla accuracy: 62.64% +- 0.01%
===
(dassl) beier@micl-zhanghwws24:~/Prompt-align/GLA.FS_LT.public$ python parse_test_res.py output/imagenet/GLA/rn50_ep50_shot4/ --test-log
Parsing files in output/imagenet/GLA/rn50_ep50_shot4/
file: output/imagenet/GLA/rn50_ep50_shot4/seed1/log.txt. gla accuracy: 63.42%. 
file: output/imagenet/GLA/rn50_ep50_shot4/seed2/log.txt. gla accuracy: 63.28%. 
file: output/imagenet/GLA/rn50_ep50_shot4/seed3/log.txt. gla accuracy: 63.24%. 
===
Summary of directory: output/imagenet/GLA/rn50_ep50_shot4/
* gla accuracy: 63.31% +- 0.08%
===
(dassl) beier@micl-zhanghwws24:~/Prompt-align/GLA.FS_LT.public$ python parse_test_res.py output/imagenet/GLA/rn50_ep50_shot8/ --test-log
Parsing files in output/imagenet/GLA/rn50_ep50_shot8/
file: output/imagenet/GLA/rn50_ep50_shot8/seed1/log.txt. gla accuracy: 64.59%. 
file: output/imagenet/GLA/rn50_ep50_shot8/seed2/log.txt. gla accuracy: 64.38%. 
file: output/imagenet/GLA/rn50_ep50_shot8/seed3/log.txt. gla accuracy: 64.47%. 
===
Summary of directory: output/imagenet/GLA/rn50_ep50_shot8/
* gla accuracy: 64.48% +- 0.09%
===
(dassl) beier@micl-zhanghwws24:~/Prompt-align/GLA.FS_LT.public$ python parse_test_res.py output/imagenet/GLA/rn50_ep50_shot16/ --test-log
Parsing files in output/imagenet/GLA/rn50_ep50_shot16/
file: output/imagenet/GLA/rn50_ep50_shot16/seed1/log.txt. gla accuracy: 65.59%. 
file: output/imagenet/GLA/rn50_ep50_shot16/seed2/log.txt. gla accuracy: 65.61%. 
file: output/imagenet/GLA/rn50_ep50_shot16/seed3/log.txt. gla accuracy: 65.69%. 
===
Summary of directory: output/imagenet/GLA/rn50_ep50_shot16/
* gla accuracy: 65.63% +- 0.04%
===
```