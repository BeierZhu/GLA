#!/bin/bash

cd ..

# custom config
DATA=/data1/CoOpData
CACHE_DIR=/data1/CacheFewShotData

TRAINER=GLA
DATASET=imagenet
CFGS=(rn50_ep50_shot1 rn50_ep50_shot2 rn50_ep50_shot4 rn50_ep50_shot8 rn50_ep50_shot16)
GPULIST=(0 1)
GPUIDX=0


for i in 0 1 2 3 4
do
    CFG=${CFGS[${i}]}
    for SEED in 1 2 3 
    do
        while true 
        do 
            sleep 5
            let GPUIDX=(GPUIDX+1)%${#GPULIST[@]}
            let STATIDX=GPULIST[GPUIDX]+2
            stat=$(gpustat | sed -n ${STATIDX}'p' | grep -o beier | wc -l)
            if [ "$stat" -lt 1 ]
            then
                break
            fi 
            echo $GPUIDX'N'
        done 
        DIR=output/${DATASET}/${TRAINER}/${CFG}/seed${SEED}
        if [ -d "$DIR" ]; then
            echo "Results are available in ${DIR}. Skip this job"
        else
            echo "Run this job and save the output to ${DIR}"
            CUDA_VISIBLE_DEVICES=${GPULIST[${GPUIDX}]} python train.py \
            --root ${DATA} \
            --seed ${SEED} \
            --trainer ${TRAINER} \
            --dataset-config-file configs/datasets/${DATASET}.yaml \
            --config-file configs/trainers/${TRAINER}/${CFG}.yaml \
            --output-dir ${DIR} \
            DATASET.CACHE_DIR ${CACHE_DIR} &
        fi
        sleep 5
        echo 'Next'
    done
done 
